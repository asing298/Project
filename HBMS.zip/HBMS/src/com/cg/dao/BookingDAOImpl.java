package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.BookingDetails;

import com.cg.entities.Hotel;
import com.cg.entities.RoomDetails;
import com.cg.entities.Users;
@Repository
public class BookingDAOImpl implements IBookingDAO{
   
	@PersistenceContext
   EntityManager manager;

	
	public EntityManager getManager() {
	return manager;
}

public void setManager(EntityManager manager) {
	this.manager = manager;
}

	//addUser
	@Override
	public Users addUser(Users user) {
		// TODO Auto-generated method stub
		manager.persist(user);
		return user;
	}

	//Login User
	@Override
	public Users validateUser(String mobileNo, String password) {
		 String query="select user from Users user where user.mobileNo=:m and user.password=:p";
		TypedQuery<Users> tquery=manager.createQuery(query, Users.class);
		tquery.setParameter("m", mobileNo);
		tquery.setParameter("p", password);
		Users u=tquery.getSingleResult();
		return u;
	}
	
	//View the list of hotels
	@Override
	public List<Hotel> viewAllHotels() {
		String query="select hotel from Hotel hotel";
		TypedQuery<Hotel> tQuery=manager.createQuery(query, Hotel.class);
		List<Hotel> hlist=tQuery.getResultList();
		return hlist;
	}

	//get Room Details
	@Override
	public List<RoomDetails> getAllRooms(long hotelId) {
		String query="select room from RoomDetails room where room.hotelId=:d";
		TypedQuery<RoomDetails> tQuery=manager.createQuery(query, RoomDetails.class);
		tQuery.setParameter("d", hotelId);
		List<RoomDetails> rlist=tQuery.getResultList();
		return rlist;
	}
	
	//add Booking Details
	@Override
	public BookingDetails addBookingDetails(BookingDetails booking) {
		manager.persist(booking);
		return booking;
	}

	//View Booking Details
	@Override
	public BookingDetails viewBookingDetails(long bookingId) {
		String query="select booking from BookingDetails booking where booking.bookingId=:b";
		System.out.println(bookingId+" In Service");
		TypedQuery<BookingDetails> tquery=manager.createQuery(query, BookingDetails.class);
		tquery.setParameter("b", bookingId);
		BookingDetails u=tquery.getSingleResult();
		System.out.println(u);
		return u;
	}
	
	
	@Override
	public BookingDetails getBooking(long bId) {
		String query="select booking from BookingDetails booking where booking.bookingId=:b";
		System.out.println(bId+" In Service");
		TypedQuery<BookingDetails> tquery=manager.createQuery(query, BookingDetails.class);
		tquery.setParameter("b", bId);
		BookingDetails book=tquery.getSingleResult();
		return book;
	}

	@Override
	public BookingDetails addBooking(BookingDetails book) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
