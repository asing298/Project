package com.cg.service;

import java.util.List;

import com.cg.entities.BookingDetails;
import com.cg.entities.Hotel;
import com.cg.entities.RoomDetails;
import com.cg.entities.Users;

public interface IBookingService {
	
	public Users addUser(Users user);
	public Users validateUser(String mobileNo,String password);
	public List<Hotel> viewAllHotels();
	public List<RoomDetails> getAllRooms(long hId);
	public BookingDetails addBookingDetails(BookingDetails booking);
    public BookingDetails viewBookingDetails(long bookingId);
    public BookingDetails getBooking(long bId);
    //public BookingDetails addBooking(BookingDetails book);
	
}
