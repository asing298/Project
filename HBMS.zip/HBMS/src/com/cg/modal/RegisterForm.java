package com.cg.modal;

import javax.validation.constraints.Pattern;

public class RegisterForm 
{
	@Pattern(regexp="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{5,15})", message="Password must be between 6 to 15 characters.\nAtleast 1 uppercase, 1 lowercase, 1 special symbol and a special character'@#$%'")
	private String password;
	@Pattern(regexp="[A-Z a-z 0-9]{5,15}",message="User Name must be 5 to 15 characters.\nAtleast 1 uppercase, 1 lower case and 1 number.")
	private String userName;
	@Pattern(regexp="[0-9]{10}",message="Mobile Number should be 10 digit long.")
	private String mobileNo;
	@Pattern(regexp="[A-Z a-z]{8}",message="Please Enter Customer as Your Role")
	private String role;
	@Pattern(regexp="[0-9]{10}",message="Alternate Number should be 10 digit long.")
	private String alternateNo;
	@Pattern(regexp="[a-z A-z 0-9]{5,50}",message="Address should be 5 to 50 characters, There should be no special character.")
	private String address;
	@Pattern(regexp="^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message="Invalid Email Address")
	private String email;
	
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAlternateNo() {
		return alternateNo;
	}
	public void setAlternateNo(String alternateNo) {
		this.alternateNo = alternateNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
