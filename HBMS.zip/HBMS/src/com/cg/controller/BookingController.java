package com.cg.controller;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.BookingDetails;
import com.cg.entities.Hotel;
import com.cg.entities.RoomDetails;
import com.cg.entities.Users;
import com.cg.modal.LoginForm;
import com.cg.modal.RegisterForm;
import com.cg.service.IBookingService;

@Controller
public class BookingController {

	@Autowired
	IBookingService service;

	public IBookingService getService() {
		return service;
	}
	public void setService(IBookingService service) {
		this.service = service;
	}

	//return login page
	@RequestMapping("login")
	public String validateUser(Model model){
		//Users user=new Users();
		LoginForm form=new LoginForm();
		model.addAttribute("form",form);
		return "Login";
	}

	//validate login and redirect
	@RequestMapping("loginAction")
	public String loginRedirect(Model model,@Valid @ModelAttribute("form") LoginForm user,BindingResult errors,
			@RequestParam("mobileNo")String MobileNo,@RequestParam("password") String Password)
	{
		if(errors.hasErrors())
		{
			return "Login";
		}
		Users u=service.validateUser(MobileNo, Password);
		model.addAttribute("validated", u);
		return "Success";
	}

	//view Register Page
	@RequestMapping("register")
	public String registerRedirect(Model model)
	{
		RegisterForm rg=new RegisterForm();
		model.addAttribute("registerForm", rg);
		return "Register";
	}

	//add user and redirect
	@RequestMapping("registerAction")
	public String addUser(Model model,@Valid @ModelAttribute("registerForm") RegisterForm rg,BindingResult errors,
			@RequestParam("userName") String userName,@RequestParam("password") String password,
			@RequestParam("role") String role,@RequestParam("mobileNo") String mobileNo,
			@RequestParam("alternateNo") String alternateNo,@RequestParam("address") String address,
			@RequestParam("email") String email)
	{
		if(errors.hasErrors())
		{
			return "Register";
		}
		else
		{
			Users user=new Users();
			user.setUserName(userName);
			user.setAddress(address);
			user.setAlternateNo(alternateNo);
			user.setEmail(email);
			user.setMobileNo(mobileNo);
			user.setPassword(password);
			user.setRole("Customer");

			Users u=service.addUser(user);
			LoginForm form=new LoginForm();
			model.addAttribute("user", u);
			model.addAttribute("form",form);
			return "Login";
		}
	}

	//show list of hotels
	@RequestMapping("showHotelListPage")
	public String showListPage(Model model){

		List<Hotel> hotelList = service.viewAllHotels();
		model.addAttribute("list", hotelList);
		return "ViewHotels";
	}

	//view Bookings of user page
	@RequestMapping("viewbooking")
	public String showGetPage(Model model)
	{
		return "ViewBooking";
	}

	//view Bookings of user
	@RequestMapping("viewBookingAction")
	public String getCourse(Model model,@RequestParam("booking") long bId){
		System.out.println(bId);
		BookingDetails book = service.getBooking(bId);
		model.addAttribute("booking",book);
		return "DisplayBooking";
	}


	//view Rooms to a user of specific hotel
	@RequestMapping("ViewRoom")
	public String showViewRoomPage(Model model,@RequestParam("hotelId") long hId){
		List<RoomDetails> roomdetails= service.getAllRooms(hId);
		model.addAttribute("roomlist", roomdetails);
		return "ViewRooms";
	}

	@RequestMapping("bookRoomPage")
	public String viewBookPage(Model model,@RequestParam("roomId")long roomId)
	{
		BookingDetails bd=new BookingDetails();
		model.addAttribute("bookRooms", bd);
		return "bookHotel";

	}

	@RequestMapping("bookingAction")
	public String bookHotel(Model model,@ModelAttribute("bookRooms") BookingDetails bd)
	{
		System.out.println(bd+" In Controller");
		service.addBookingDetails(bd);
		return "DisplayBooking";
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		sdf.setLenient(true);
		binder.registerCustomEditor(BookingDetails.class, new CustomDateEditor(sdf, true));
	}

}
