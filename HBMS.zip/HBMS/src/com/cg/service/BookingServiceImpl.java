package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookingDAO;
import com.cg.entities.BookingDetails;
import com.cg.entities.Hotel;
import com.cg.entities.RoomDetails;
import com.cg.entities.Users;
@Service
@Transactional
public class BookingServiceImpl implements IBookingService {

	@Autowired
	IBookingDAO dao;
	
	public IBookingDAO getDao() {
		return dao;
	}

	public void setDao(IBookingDAO dao) {
		this.dao = dao;
	}

	@Override
	public Users addUser(Users user) {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}

	@Override
	public Users validateUser(String mobileNo, String password) {
		// TODO Auto-generated method stub
		return dao.validateUser(mobileNo, password);
	}

	@Override
	public List<Hotel> viewAllHotels() {
		// TODO Auto-generated method stub
		return dao.viewAllHotels();
	}

	@Override
	public List<RoomDetails> getAllRooms(long hotelId) {
		// TODO Auto-generated method stub
		return dao.getAllRooms(hotelId);
	}

	@Override
	public BookingDetails addBookingDetails(BookingDetails booking) {
		// TODO Auto-generated method stub
		return dao.addBookingDetails(booking);
	}

	@Override
	public BookingDetails viewBookingDetails(long bookingId) {
		// TODO Auto-generated method stub
		return dao.viewBookingDetails(bookingId);
	}

	@Override
	public BookingDetails getBooking(long bId) {
		// TODO Auto-generated method stub
		return dao.getBooking(bId);
	}

	

	
}
