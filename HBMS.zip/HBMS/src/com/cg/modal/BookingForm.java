package com.cg.modal;

import java.util.Date;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

public class BookingForm 
{
	@Temporal(TemporalType.DATE)
	private Date booked_from;
	@Temporal(TemporalType.DATE)
	private Date booked_to;
	@Size(max=1,message="Please enter valid number of Adults")
	private int numberOfAdults;
	@Size(max=1,message="Please enter valid number of Children's")
	private int noOfChildren;
	public Date getBooked_from() {
		return booked_from;
	}
	public void setBooked_from(Date booked_from) {
		this.booked_from = booked_from;
	}
	public Date getBooked_to() {
		return booked_to;
	}
	public void setBooked_to(Date booked_to) {
		this.booked_to = booked_to;
	}
	public int getNumberOfAdults() {
		return numberOfAdults;
	}
	public void setNumberOfAdults(int numberOfAdults) {
		this.numberOfAdults = numberOfAdults;
	}
	public int getNoOfChildren() {
		return noOfChildren;
	}
	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}
}
