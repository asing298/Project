package com.cg.modal;

import javax.validation.constraints.Pattern;

public class LoginForm 
{
	@Pattern(regexp="[0-9]{10}",message="Mobile Number should be 10 digit long.")
	private String mobileNo;
	 
	//@Pattern(regexp="[A-Z a-z 0-9 ]{10}",message="Mobile Number should be 10 digit long.")
	private String password;
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
